
def bsalary(salary):
    print("salary :",salary)
    da=float(salary*80/100)
    print("da is : ",da)
    hra=float(salary*15/100)
    print("house rent allowance : " ,hra)
    pf=float(salary*12/100)
    print("provident fund : ",pf)
    itax=float(salary*0.1)
    print("income tax :" ,itax)
    net_salary=float(salary+da+hra)
    print("Net Salary  :",net_salary)
    gross_salary=(net_salary - pf-itax)
    print("Gross Salary  :", gross_salary)




  

#b=float(input("Enter the Salary : "))

#bsalary(b)

