class Student:
    def __init__(self,__marks):
        self.__marks=__marks
    def getter(self , id, name):
         self.id=id
         self.name=name
    def setter(self):
        print("**************Student Details*******************")
        print("student Id  : ", self.id)
        print("student Name  : ", self.name)
        print("student Marks: ", self.__marks)

    def __del__(self):
        print("Student class object deleted.")

m=int(input("Enter the marks : "))
s=Student(m)
i=int(input("Enter the Id : "))
n=input("Enter the Name : ")
s.getter(i,n)
s.setter()
del s
