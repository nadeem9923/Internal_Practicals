class Error(Exception):
      pass

class ValueTooSmallError(Error):
      pass

try:
    balance=int(input("Enter the balance "))
    if balance<1000:
        raise ValueTooSmallError
except ValueTooSmallError:
      print("You can withdraw bec balance is less than 1000")
else:
      print("balance is not enough")
