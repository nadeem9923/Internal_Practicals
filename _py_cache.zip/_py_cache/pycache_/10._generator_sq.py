def generator(x,y):
    while(x<=y):
        r=x*x
        yield r
        x+=1
num=generator(1,10)
for i in num:
    print(i,end=" ")
