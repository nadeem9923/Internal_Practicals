import math

while True:
    
    print("\n1.ceil of no :")
    print("2.floor of no :")
    print("3.sqrt of no :")
    print("4.pow of no :")
    print("5.exp of no :")
    print("6.log of no :")
    print("7.Addition :")
    print("8.Substraction :")
    print("9.Exit")
    
    choice1 = int(input("\nEnter the Choice:"))  

    if choice1 == 1:  
       print("ceil function : " ,math.ceil(4.5867))
   
    elif choice1 == 2:  
       print("floor function : ",math.floor(4.5687))
   
    elif choice1 == 3:  
       print("sqrt function :",math.sqrt(100))
   
    elif choice1 == 4:  
       print("pow function :",math.pow(2,4))
   
    elif choice1 == 5:
       print("exp function : ",math.exp(10))
   
    elif choice1 == 6:  
       print("log function : ",math.log10(10))
    elif choice1 == 7:  
       print("addition of 5 and 10 : ",5+10)
    elif choice1 == 8:  
       print("addition of 20 and 10 : ",20-10)
       break
     
    else:
        print("Enter correct choice")

 
 
