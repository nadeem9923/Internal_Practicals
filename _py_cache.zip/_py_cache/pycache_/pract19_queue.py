queue=[]
def Enqueue():
    if len(queue)==size:
        print("Queue is Full ")
    else:
        e=input("Enter the element ")
        q.append(queue)
        
def dequeue():
    if not queue:
        print("Queue is Empty ")
    else:
        e=queue.pop(0)
