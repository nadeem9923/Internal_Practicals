T1=(10,50,20,9,40,20)
print("Tuple element :",T1)
L1=list(T1)
L1.append(100)
T1=tuple(L1)
print("After adding element :",T1)

y = list(T1)
y[1] = 30
x = tuple(y)
print("After updating element :", x)

y = reversed(x)
print("Reverse of the Tuples ",tuple(y))



count = T1.count(20)
print("20 appears ",count," times in the tuples")


