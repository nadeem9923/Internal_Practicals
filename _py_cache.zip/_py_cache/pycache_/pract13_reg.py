#WAP to validate email id using regular expression
import re

regex = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
def check(email):
	if(re.fullmatch(regex, email)):
		print("Valid Email")
	else:
		print("Invalid Email")

if __name__ == '__main__':

	email = "mideshmukh326@gmail.com"     # Enter the email
	check(email)                        # calling run function

	email = "my.ownsite@our-earth.org"
	check(email)

	email = "deshmukhmii2.com"
	check(email)
