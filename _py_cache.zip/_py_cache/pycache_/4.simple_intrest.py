def interest(p,t,r):
    si=(p*t*r)/100
    return si
p=int(input("Enter the principle amount : "))
t=int(input("Enter of years : "))
r=int(input("Enter the rate of interest : "))
si=interest(p,t,r)
print(si)
    
