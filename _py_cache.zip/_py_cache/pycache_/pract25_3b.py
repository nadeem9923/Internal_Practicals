import re
def text_match(text):
        patterns = 'ab{2,3}'
        if re.search(patterns,  text):
                return 'Found a match!'
        else:
                return('Not matched!')
str1=input("Enter first string :")
str2=input("Enter sec string :")
print("string first ",text_match(str1))
print("string sec ",text_match(str2))

#Write a Python program that matches a string that has an a followed
#by two to three 'b'
