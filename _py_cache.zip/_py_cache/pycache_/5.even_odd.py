a=[3,8,9,3,2]
even=[]
odd=[]
for j in a:
  if(j%2==0):
    even.append(j)
  else:
    odd.append(j)
print("list : ",a)
print("even num list : ",even)
print("odd num list : ",odd)
