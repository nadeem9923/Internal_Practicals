from datetime import date
today = date.today()
print("Today date is: ", today)
l_date = date(2022, 12, 31)
delta = l_date - today
print(delta.days ,"days remaining upto 31st Dec 2022")
