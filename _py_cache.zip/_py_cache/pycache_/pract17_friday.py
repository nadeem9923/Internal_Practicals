import time
print("\nday nd Date format")
t=time.strftime("%A,%d %B %Y" ,time.gmtime())
print(t)
