stack=[]
while True:
    print("\n*******Enter the choice as per given*****\n ")
    print("1.Insert element in the stack.\n ")
    print("2.Delete element from the Stack\n ")
    print("3.Display stack element\n ")
    print("4.Exit")
    print()
    user=int(input("Enter your choice : "))
    if user == 1:
       d=input("Enter the name of  student : ")
       stack.append(d)
    elif user == 2 :
        if stack == []:
            print("underflow ")
        else:
            stack.pop()
    elif user == 3:
        print("Stack List : ",stack)
    else:
        break
    #print("now our stack : ",stack)
        
    

    

    

    
    
