import re
def is_allowed_specific_char(string):
    charRe = re.compile(r'[^a-zA-Z0-9]')
    string = charRe.search(string)
    return not bool(string)
str1=input("Enter first string :")
str2=input("Enter sec string :")
print("First string ",is_allowed_specific_char(str1)) 
print("sec string ",is_allowed_specific_char(str2))



