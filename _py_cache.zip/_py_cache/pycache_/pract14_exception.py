#Attribute error
class Attributes(object):
	pass
try:
        object = Attributes()
        print (object.attribute)
except:
        print("Attribute error")


#IndexError
try:
	a = [1, 2, 3]
	print (a[3])
except LookupError:
	print ("Index out of bound error.")
else:
	print ("Success")



#exception ArithmeticError
try:
	a = 10/0
	print (a)
except ArithmeticError:
	print ("This statement is raising an arithmetic exception.")
else:

	print ("Success.")

#Exception Keyerror
try:
        array = { 'a':1, 'b':2 }
        print (array['c'])
except:
        
        print("Exception Keyerror")

#exception StopIteration
try:
        Arr = [3, 1, 2]
        i=iter(Arr)

        print (i)
        print (i.next())
        print (i.next())
        print (i.next())
        print (i.next())
except :
        print("exception StopIteration")
