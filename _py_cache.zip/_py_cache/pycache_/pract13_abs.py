from abc import ABC, abstractmethod
class Car(ABC):
   @abstractmethod
   def carno(self,no):
   
      @abstractmethod
      def breking(self):
         pass

class Maruti(Car):
  def carno(self,no):
      print("Maruti car no :",no)
  def steering(self):
      print("steering of maruti class ")
  def breking(self):
      print("press the break of maruti car")
      

class Scarano(Car):
  def carno(self,no):
      print("Scarano car no :",no)
  def steering(self):
      print("steering of Scarano class ")
  def breking(self):
      print("press the break of maruti car")
      

class Volkswagen(Car):
  def carno(self,no):
      print(" Volkswagen car no :",no)
  def steering(self):
      print("steering of Volkswagen class ")
  def breking(self):
      print("press the break of maruti car")

n=input("Enter the car registration no :")
m=Maruti()
m.carno(n)
m.steering()
m.breking()

n1=input("Enter the car registration no :")
s=Scarano()
s.carno(n1)
s.steering()
s.breking()

n2=input("Enter the car registration no :")
v=Volkswagen()
v.carno(n2)
v.steering()
v.breking()
      

      
      
      
