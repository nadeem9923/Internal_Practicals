import pract_11_empsalary
import pract11_empinfo


name=(input("Enter the Name of Employee : "))
des=(input("Enter the Designation: "))
dept=(input("Enter the Department : "))
quali=(input("Enter the Qualification : "))
exp=int(input("Enter the Experince: "))
pract11_empinfo.diaplay(name,des,dept,quali,exp)

print("--------------------------------------------------")
b=float(input("Enter the Salary : "))
pract_11_empsalary.bsalary(b)
