def diaplay(name,designation,dept,quali,experience):
    print("************* Employee Details *****************")
    print("Name of the Employee: ",name)
    print("Post of the Employee: ",designation)
    print("Department of the Employee: ",dept)
    print("Qualification of the Employee: ",quali)
    print("Experience is : ",experience,"yr's")

#diaplay()
