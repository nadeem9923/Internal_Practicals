def decore(fun):
    def inner():
        value=fun()
        return value*value*value
    return inner
def read():
    num=int(input("Enter the number : "))
    return num
result=decore(read)
print("cube of given num is : ",result())
