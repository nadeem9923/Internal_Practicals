
a=[2,5,6,8,4,3]
n=len(a)
mean=sum(a)/n
print(mean)
print("lenght :",n)
n=sum(a)
print("sum :",n)
n=len(a)
print("lenght :",n)
n=min(a)
print("min :",n)
n=max(a)
print("max :",n)

